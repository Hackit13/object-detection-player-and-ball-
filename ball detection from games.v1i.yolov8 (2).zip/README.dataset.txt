# ball detection from games > 2024-05-06 8:13pm
https://universe.roboflow.com/swati-o56sn/ball-detection-from-games

Provided by a Roboflow user
License: CC BY 4.0

